import { env } from '../../../config/env';
import { LocalDiskDriver } from './LocalDiskDriver';
import type { StorageDriver } from './StorageDriver';

/**
 * Single place that decides which driver is live. Adding S3 later is:
 *
 *   case 's3': return new S3Driver();
 *
 * plus a `media_migrations` run to copy the files and flip `media.disk`.
 * No call site changes.
 */
function createDriver(): StorageDriver {
  switch (env.storage.driver) {
    case 'local':
      return new LocalDiskDriver();
    case 's3':
      throw new Error('S3 storage driver is not implemented yet. Set STORAGE_DRIVER=local.');
    default:
      throw new Error(`Unknown STORAGE_DRIVER: ${env.storage.driver}`);
  }
}

export const storage: StorageDriver = createDriver();
export { LocalDiskDriver };
export type { StorageDriver };
